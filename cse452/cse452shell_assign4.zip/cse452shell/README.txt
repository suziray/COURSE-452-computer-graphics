Name: Ray Su
Student Id: 432026
Email: suz@wustl.edu
Assignment 4: Intersecting Shapes

Implementation:
Shape s is the only variable I added in IntersectionUI. I created a virtual function "intersect" in Shape class, 
and specified the returns in each individual shapes including Sphere, Cylinder, Cube, Cone. For Cylinder and Cone, 
I made the program firstly check for intersections with the caps, and the edge cases would create normals on the caps 
instead of on the bodies.
I have also modified the writeTest() method, which gives the same answer as the Demo after inputting same seeds.

Extra Credit:
I implemented SpecialShape2 in this lab, which is an ellipsoid that I created in Assignment 2. 
(It is unreasonable to implement on SpecialShape1 because the shape is too complicated)

Known Bug:
NONE