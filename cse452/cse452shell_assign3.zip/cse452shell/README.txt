Name: Ray Su
Student Id: 432026
Email: suz@wustl.edu
Assignment 3: Camera

Additional Methods:
update_u, update_v, update_n are used to update u, v, and n when nevessary.
update_T, update_R, update_Sxy, update_Sxyz, update_D are used when the 
transformation matrices need to be updated due to various set calls.

Extra Credit:
I included Aspect Ratio in my lab. Instead of storing width and height, I 
made height and a, and use a*h when w is wanted.

Known Bug:
I have consulted TA but cannot solve this one bug: the view port is in the 
correct size when the program starts, but when play/pause is hitted, 
one side of the view port shrinks and the whole port change to a square