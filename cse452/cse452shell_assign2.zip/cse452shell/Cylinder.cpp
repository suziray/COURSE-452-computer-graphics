#include "Cylinder.h"

using namespace std;

Cylinder::Cylinder()
{
}

Cylinder::~Cylinder()
{
}

void Cylinder::newTess(int t1, int t2)
{
	ts = vector<Triangle>();
	double h = 1.0 / t2;
	double r = 2 * M_PI / t1;
	Matrix3 m = rotater(r); // for rotation
	Vector3 vU = Vector3(.5, .5, 0);
	Vector3 vL = Vector3(.5, -.5, 0);
	Vector3 nM = Vector3(cos(r / 2.0), 0, -sin(r / 2.0));
	for (int i = 0; i < t1; i++){
		Vector3 vU1 = m*vU;
		Vector3 vL1 = m*vL;	
		Vector3 nor = Vector3(0, 1, 0); // up side
		addTri(Vector3(vU[0], vU[1], vU[2]), Vector3(vU1[0], vU1[1], vU1[2]), Vector3(0, 0.5, 0), nor);
		nor = Vector3(0, -1, 0); // down side
		addTri(Vector3(vL1[0], vL1[1], vL1[2]), Vector3(vL[0], vL[1], vL[2]), Vector3(0, -0.5, 0), nor);
		nor = nM;
		for (int j = 0; j < t2; j++){
			addTri(Vector3(vL[0], vL[1] + j*h, vL[2]), Vector3(vL1[0], vL1[1] + j*h, vL1[2]), Vector3(vL1[0], vL1[1] + (j + 1)*h, vL1[2]), nor);
			addTri(Vector3(vL[0], vL[1] + j*h, vL[2]), Vector3(vL1[0], vL1[1] + (j + 1)*h, vL1[2]), Vector3(vL[0], vL[1] + (j+1)*h, vL[2]), nor);
		}
		vU = vU1;
		vL = vL1;
		nM = m*nM;
	}
}