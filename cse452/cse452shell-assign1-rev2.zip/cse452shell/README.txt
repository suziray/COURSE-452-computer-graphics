Name: Ray Su
Student Id: 432026
Email: suz@wustl.edu
Assignment 1: Airbrush

PART 1: Airbrush
I modified MyBrush::changedBrush to update the mask used by 
the airBrush when there is a change in the brush parameters. 
The mask is basically a matrix with size r by r, where r is 
the radius provided by the user through the interface.
I have accomplished CONSTANT, LINEAR, QUADRATIC and GAUSSIAN (for extra)
masks, and in the GAUSSIAN case I assumed a standard normal distribution 
with mean = 0 and variance = 1.

For the SPECIAL mask (for extra), I created a "double-donut," which would 
determine if the pixel is within half radius region from 
the origin or larger than half, and then calculate the mask 
value base on how far the pixel is from the middle circle of 
the region.

Then, when I drawBrush, I used xUBound, xLBound, yUBound and 
yLBound to mark the limit of the brush paint. I created a 
deposit method which takes into the original color, the brush 
color, and the mask factor (including pixel flow) and return the 
ending color in the form of a double vector with length 3.

To determine which mask position I should use for each to-be-brushed
pixel, I simply calculated the relative position from that pixel 
to the origin and converted to absolute values.

PART 2.1: drawLine (this is not for extra credit, I chose to mainly do this)
I firstly got the beginning and ending points of the line from 
mouseDown and mouseDrag. Then I created a 4 by 2 matrix vx to store 
the desired 4 vertices of the to-be-drawn rectangle. I calculated the 
coordinates of the vertices based on the beginning, ending point, and 
dy and dx which actually represents the sin and cos of the slope of the 
desired thick line (which enabled me to get more accurate coordinates 
when I multiply the cos and sin with the radius (length of the 2 edges 
perpendicular to the drawn line) and add the result to the starting and 
ending points.

Secondly, I stored the vertices by pairs into the vector edge, which 
contains the 4 edges of the rectangle. I wrote a sort method here 
to help sort arrays stored in STL, which is helpful in scan-line 
algorithms. By sorting the y-values of the vertices I got the lowest 
and highest y-values yMin and yMax, which are needed for the scanning part.

Thirdly, I created a scanline function, which takes into a vector that 
contains 4 values (2 pairs of coordinates of a line's ending points) 
and a y value. This function would return the corresponding x-value that 
represents the intersection between the line and a horizontal line with 
y-value = y.

Back into the drawLine function, looping through yMin to yMax and through 
each edge, I would run scanline on an edge if the current y is within the
edge's y range (I would ignore edges with lower y-limit = current y, since 
we consider no intersection between a scan line and a edge's lowest point), 
and push the result into a vector. Since this is just a rectangle, I would 
have at most 2 values in the the intersection vector for each y. I would 
then turn on the pixels in between them

PART 2.2: drawCircle (as mentioned, this is not for extra credit)
I did not only draw one of the 8 parts of a circle and then copy to the other 
parts because it would make the bound check too complicate and therefore increase 
complexity. Different from the preview part, here the program would draw only 
when we release the mouse, which would not cause to much difference.

I firstly calculated the desired circle radius from the position of the mouse, 
and then looped through (with bound check on the limits) the pixels within the 
rectangle centered at the origin (with edge length 2*(radius + thickness)).
If a pixel's distance from the origin is within the radius +/- thickness range, 
it would be turned on.

I did drawPolygon for extra credit!

COMPLEXITY ANALYSIS
If using drawBrush, the program would draw one eighth of a circle (the NE to N
part), and copy it over to the other 8 directions. This would reduce complexity 
since we reduced the loop size. Moreover, each time we would directly calculate
the y value, which is faster then also looping through y and using if function.

If using drawLine, we would calculate the 4 vertices of the rectangle using the 
method mentioned in part 2.1. Then we simply implemented GL_POLYGON to connect 
the edges and fill the rectangle, which is much faster than draw parallel lines 
to form a rectangle.

If using drawCircle, we would use GL_LINES to draw the first quadrant part of the
circle by connecting left and right boundaries at each y level by directly computing
the x values, which reduces complexity. Then we simply copy the one forth circle to
the other 3 parts. We did not divide to 8 parts because there is thickness and 
drawing 8 parts would repeat on too many pixels using the same function.
