#include "../cse452.h"
#include "MyScene.h"
#include "Cone.h"
#include "Sphere.h"
#include "Cylinder.h"
#include "Cube.h"
#include "Shape.h"
#include "SpecialShape2.h"
#include "SpecialShape1.h"

using namespace std;

void MyScene::resize(int w, int h) {
    // resize the film plane to the specified width/height
    camera.setWidthHeight(w, h);
}

/// Note: your camera and screen clear, etc, will be set up by
/// SceneviewUI.cpp *before* this gets called
void MyScene::draw() {
    // render the scene using OpenGL
    if (!isLoaded) // Don't draw if loadSceneFile hasn't been called yet
        return;


    // Turn off all lights
    for ( int i = 0; i < 7; i++ )
        glDisable( GL_LIGHT0 + i );

    //  .. and reset
    glLightModelfv( GL_LIGHT_MODEL_AMBIENT, &ambientLight[0] );
    for (unsigned int i = 0; i < lights.size(); i++) {
        lights[i].setOpenGLLight( GL_LIGHT0 + i );
    }

    // TODO: draw the rest of the scene here
	
	for (unsigned i = 0; i < objList.size(); ++i){
		Object obj = objList[i];
		glPushMatrix();
		glMultMatrixd(&obj.trans(0, 0));
		glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, &obj.ambient[0]);
		glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, &obj.diffuse[0]);
		glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, &obj.specular[0]);
		glMaterialfv(GL_FRONT_AND_BACK, GL_EMISSION, &obj.emit[0]);
		glMaterialf(GL_FRONT_AND_BACK, GL_SHININESS, obj.shine);
		// 0 for Cube, 1 for Cylinder, 2 for Cone, 3 for Sphere, 4 for Ellipsoid, 5 for Cactus
		if (obj.shape == 0){
			obj.shapeptr = make_shared<Cube>();
			obj.shapeptr->newTess(5, 5);
		} else if (obj.shape == 1){
			obj.shapeptr = make_shared<Cylinder>();
			obj.shapeptr->newTess(100, 5);
		} else if (obj.shape == 2){
			obj.shapeptr = make_shared<Cone>();
			obj.shapeptr->newTess(100, 5);
		} else if (obj.shape == 3){
			obj.shapeptr = make_shared<Sphere>();
			obj.shapeptr->newTess(5, 5);
		} else if (obj.shape == 4){
			obj.shapeptr = make_shared<SpecialShape2>();
			obj.shapeptr->newTess(10, 5);
		} else if (obj.shape == 5){
			obj.shapeptr = make_shared<SpecialShape1>();
			obj.shapeptr->newTess(5, 5);
		}
		obj.shapeptr->drawTriangles();
		glPopMatrix();
	}
		
}