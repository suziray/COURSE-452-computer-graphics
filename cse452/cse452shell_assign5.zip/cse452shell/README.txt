Name: Ray Su
Student Id: 432026
Email: suz@wustl.edu
Assignment 5: Scene View

Implementation:
I created classes Node and Object in MyScene.h

Object has a int index for its shape, and shared_ptr for its shape variable (which is good for memory 
management), colors/numbers such as diffuse, specular, and so on, a Matrix4 trans which is the 
transformation matrix it inherits from its parent during flattening, and a flatten method used for 
pushing an object into the object list that would be used for drawing

Node has a bool indicating whether it has an object, a pointer to its object, a vector of pointers to 
its child nodes, a Matrix4 transform used for transformation, and a flatten method that would determine
whether it has an object (then call flatten obj) or it has more child nodes (then call itself recursively)

I created global variables map, objList, nodes, and objs for MyScene. map is a hashmap used to store 
and access subgraphs (it maps string to node). objList is used to store all objects, which are used for drawing. 
nodes are used to store pointers to all the nodes (trans and subgraph nodes) that are created during 
parsing, which is important for controlling memory. objs are used for storing pointers to all objects, 
which is also for memory control.

In MyScene.cpp, I successfully implemented all the parsing functions, and made proper changes for situations
that data are bad. I have implemented the reset function such that every time all the objects / nodes / map 
that are created would be deleted / cleared, and there is no memory leaking.

In MyScene_draw.cpp, I iterate through the objList that was filled up by my flatten function earlier, and 
read in all the color and transformation information for each object, and then use the drawTriangles function 
to draw each object's shape. I have implemented the OpenGL matrix functions to make this work correctly.

Extra Credit:
I added two keywords "ellipsoid" and "cactus", which represent two special shapes that I created. They are 
used in my self-designed scene file, which is named "war_and_peace.sc" and can be found in the same directory 
as this README text file.

I also passed the extra path tracing test.

Known Bug:
NONE